﻿using UnityEngine;
using System.Collections;

public class movearound : MonoBehaviour {

    public Animator anim;   //What I call my animator variable
    private bool matter;    //Trigger used in this case for animations


    // Use this for initialization
    void Start() {
        anim = GetComponent<Animator>();    //making the animator variable this objects attatched animator component
        matter = false;                     //setting the base state of trigger
    }                                   

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))            //What is done for the first animation to play
        {
            anim.Play("SplatAni", -1, 0f);          //Animator playing the animation called "SplatAni"
        }

        if (matter) {                               //trigger for on/off cycling between two animations
            if (Input.GetMouseButtonDown(1))
            {
                anim.Play("Cloud", -1, 0f);         //Animator playing the animation called "Cloud"
                matter = false;
            }
        }
        else
        {
            if (Input.GetMouseButtonDown(1))
            {
                anim.Play("Normal", -1, 0f);        //Animator playing the animation called "Normal"
                matter = true;
            }
        }
    }
}